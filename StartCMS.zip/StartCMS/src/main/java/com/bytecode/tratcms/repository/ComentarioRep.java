package com.bytecode.tratcms.repository;

import com.bytecode.tratcms.model.Comentario;

public interface ComentarioRep extends BaseRep<Comentario>{
}
