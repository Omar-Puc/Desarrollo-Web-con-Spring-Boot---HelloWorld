package com.bytecode.tratcms.util;

public class ApiSubError {
}
