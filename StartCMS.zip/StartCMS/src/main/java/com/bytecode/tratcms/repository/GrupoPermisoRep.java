package com.bytecode.tratcms.repository;

import com.bytecode.tratcms.model.GrupoPermiso;

public interface GrupoPermisoRep extends BaseRep<GrupoPermiso> {

}
