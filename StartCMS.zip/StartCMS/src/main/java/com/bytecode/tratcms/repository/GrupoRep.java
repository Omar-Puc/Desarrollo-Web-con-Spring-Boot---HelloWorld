package com.bytecode.tratcms.repository;

import com.bytecode.tratcms.model.Grupo;

public interface GrupoRep extends BaseRep<Grupo> {

}
