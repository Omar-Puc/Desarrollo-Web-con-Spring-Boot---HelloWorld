package com.bytecode.tratcms.repository;

import com.bytecode.tratcms.model.Contenido;

public interface ContenidoRep extends BaseRep<Contenido> {

}
