package com.bytecode.tratcms.repository;

import com.bytecode.tratcms.model.UsuarioMetadata;

public interface UsuarioMetadaRep extends BaseRep<UsuarioMetadata> {

}
