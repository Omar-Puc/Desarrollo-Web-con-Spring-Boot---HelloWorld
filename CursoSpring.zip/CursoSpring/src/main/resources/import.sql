insert into permiso (Nombre) value('Administracion');
insert into permiso (Nombre) value('Usuarios');
insert into permiso (Nombre) value('Post');