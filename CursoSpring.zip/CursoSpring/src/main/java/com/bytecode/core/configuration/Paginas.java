package com.bytecode.core.configuration;

public class Paginas {
	public static String HOME = "index";
	public static String POST = "post";
}
