package com.bytecode.core.model;

public class Usuario {
	private String nombre;
	private String apellido;
	
}
